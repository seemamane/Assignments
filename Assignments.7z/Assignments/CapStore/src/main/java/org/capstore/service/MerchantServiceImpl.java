package org.capstore.service;

import java.util.List;

import javax.persistence.Transient;

import org.capstore.dao.MerchantDao;
import org.capstore.dao.MerchantDaoImpl;
import org.capstore.domain.Merchant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MerchantServiceImpl implements MerchantService {

	@Autowired
	MerchantDao merchantDao=new MerchantDaoImpl();

	
	@Transactional
	public void saveMerchant(Merchant merchant) {
		
		merchantDao.saveMerchant(merchant);


	}

	@Transactional
	public List<Merchant> getAllMerchants() {
		
		return merchantDao.getAllMerchants();
	}

	@Transactional
	public void deleteMerchant(Integer merchant_id) {
		merchantDao.deleteMerchant(merchant_id);
		
	}

	

}
