package org.capstore.service;

import java.util.List;

import org.capstore.domain.Feedback;
import org.capstore.domain.Merchant;
;



public interface FeedbackService {
	public void saveFeedback(Feedback feedback);
	public List<Merchant> getAllMerchant();
	public List<Feedback> getAllFeedback();
	//public void acceptFeedback(Integer feedback_id);

/*	public List<Merchant> getAllMerchant();*/
}
