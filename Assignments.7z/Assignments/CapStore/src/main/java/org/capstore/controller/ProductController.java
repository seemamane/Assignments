package org.capstore.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.capstore.domain.Product;
import org.capstore.service.CategoryService;
import org.capstore.service.MerchantService;
import org.capstore.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {

	@Autowired
	public CategoryService categoryService;
	@Autowired
	public ProductService productservice;
	@Autowired
	public MerchantService merchantservice;
	

	public Product searchProduct=null;
	
	
	
	
	
	@RequestMapping("/ProductForm")
	public String showProductForm(Map<String, Object> maps){
	/*	SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy");
		List<Employee> employees= employeeService.getAllEmployees();
		maps.put("emps",employees);
		maps.put("empSearch",searchEmployee);*/
		maps.put("prod",new Product());
		maps.put("categorys", categoryService.getAllCategories());
		maps.put("brands", productservice.getAllBrands());
		maps.put("merchants", merchantservice.getAllMerchants());
		maps.put("sub_categories", productservice.getAllSub_category());
		//maps.put("stocks", productservice.getAllStock());
		 return "Product";
	}
	
	@RequestMapping(value={"/showProduct"},method=RequestMethod.POST)
	public ModelAndView saveProductDetails(Map<String, Object> maps,
			@Valid @ModelAttribute("prod") Product prod, BindingResult result){
		
		if(result.hasErrors()){
			maps.put("categorys", categoryService.getAllCategories());
			maps.put("brands", productservice.getAllBrands());
			maps.put("merchants", merchantservice.getAllMerchants());
			maps.put("sub_categories", productservice.getAllSub_category());
			return new ModelAndView("Product");
		}
		else{
			//System.out.println("After in conntroller"+prod);
			productservice.saveProduct(prod);
			maps.put("categorys", categoryService.getAllCategories());
			maps.put("brands", productservice.getAllBrands());
			maps.put("merchants", merchantservice.getAllMerchants());
			maps.put("sub_categories", productservice.getAllSub_category());
			maps.put("prod", new Product());
			return new ModelAndView("Product");
		}
		
		
	}
	
	
	
	@RequestMapping(value="/listAll")
	public String showAllProducts(Map<String,Object>maps){
		List<Product> list=productservice.getAllProducts();
		
		
		
		System.out.println("controller"+list);
		maps.put("productList",list);
		
		return "ListAllProduct";
		
	}
	
	
	@RequestMapping(value="/DeleteProduct")
	public String deleteProducts(Map<String,Object>maps){
		List<Product> list=productservice.getAllProducts();
		maps.put("productList",list);
		
		return "DeleteProduct";
		
	}
	
	@RequestMapping(value="/deleteProduct/{product_id}")
	public String deleteProductByID(@PathVariable("product_id") Integer product_id,Map<String,Object>maps){
		
		
		List<Product> list=productservice.getAllProducts();
		maps.put("productList",list);
		productservice.deleteProduct(product_id);
		
		
		return "redirect:/DeleteProduct";
		
	}
	
	
	@RequestMapping(value="/UpdateProduct")
	public String updateProduct(Map<String,Object>maps){
		List<Product> list=productservice.getAllProducts();
		//System.out.println("controller"+list);
		maps.put("productList",list);
		
		return "UpdateProduct1";
		
	}
	
	@RequestMapping(value="/updateProduct/{product_id}")
	public String  updateProductBYID(@PathVariable("product_id") Integer product_id,Map<String, Object>maps){
		SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy");
		System.out.println("Update");
		Product product=productservice.searchProduct(product_id);
		searchProduct=product;
	    Date date_of_posting=searchProduct.getDate_of_posting();
	    if(date_of_posting!=null)
		{		
				String dateOfPosting=myFormat.format(date_of_posting);
			    maps.put("dop", dateOfPosting);
				
		}
	    
	    
		maps.put("prod", searchProduct);
		maps.put("categorys", categoryService.getAllCategories());
		maps.put("brands", productservice.getAllBrands());
		maps.put("merchants", merchantservice.getAllMerchants());
		maps.put("sub_categories", productservice.getAllSub_category());
      
		return"UpdateProduct";
	}
	
	
	@RequestMapping(value={"/updateProductNew"})
	public ModelAndView saveProductDetailsAfterUpdate(Map<String, Object> maps,
			@Valid @ModelAttribute("prod") Product prod, BindingResult result){
		/*List<Product> products= productservice.getAllProducts();
		map.put("products1",products);*/
		//map.put("empSearch",searchEmployee);
		//System.out.println(prod);
		/*if(result.hasErrors()){
			return new ModelAndView("Product","categorys",categoryService.getAllCategories());
		}
		else{*/
			System.out.println("After in conntroller"+prod);
			productservice.saveProduct(prod);
			maps.put("categorys", categoryService.getAllCategories());
			maps.put("brands", productservice.getAllBrands());
			maps.put("merchants", merchantservice.getAllMerchants());
			maps.put("sub_categories", productservice.getAllSub_category());
			//maps.put("prod", new Product());
			return new ModelAndView("Product");
		
		
	}
	
}
