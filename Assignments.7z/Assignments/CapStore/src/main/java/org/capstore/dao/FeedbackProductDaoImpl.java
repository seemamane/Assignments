package org.capstore.dao;

import java.util.List;

import org.capstore.domain.FeedbackProduct;
import org.capstore.domain.Merchant;
import org.capstore.domain.Product;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
public class FeedbackProductDaoImpl implements FeedbackProductDao {

	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public void saveFeedbackProduct(FeedbackProduct feedbackProduct) {
		
		System.out.println(feedbackProduct);
		sessionFactory.getCurrentSession().saveOrUpdate(feedbackProduct);
		
		
	}




	@Override
	public List<Product> getAllProduct(){

	List<Product>products= sessionFactory.getCurrentSession().createQuery("from Product").list();
		System.out.println(products);
		return products;
	}
	

}
