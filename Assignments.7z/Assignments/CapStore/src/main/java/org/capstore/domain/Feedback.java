package org.capstore.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
public class Feedback {
	@Id
	@GeneratedValue
	private int	feedback_id;
	
	@NotEmpty(message="* Please enter Feedback.")
/*	@Column(nullable=false)*/
	private String feedback_merchant;
	
	/*
	@Transient
	@Column(nullable=false)
	@NotEmpty(message="* Please select a merchant.")
	private String merchant_name;*/
	
	@ManyToOne//(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="merchant_id_FK")
	private Merchant merchant;
	

	
	
	//no arg constructor
	public Feedback(){
		
	}

	public Feedback(int feedback_id, String feedback_merchant, Merchant merchant) {
		super();
		this.feedback_id = feedback_id;
		this.feedback_merchant = feedback_merchant;
		this.merchant = merchant;
		
	}

	public int getFeedback_id() {
		return feedback_id;
	}

	public void setFeedback_id(int feedback_id) {
		this.feedback_id = feedback_id;
	}

	public String getFeedback_merchant() {
		return feedback_merchant;
	}

	public void setFeedback_merchant(String feedback_merchant) {
		this.feedback_merchant = feedback_merchant;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	@Override
	public String toString() {
		return "Feedback [feedback_id=" + feedback_id + ", feedback_merchant=" + feedback_merchant + ", merchant="
				+ merchant + "]";
	}


	
	
}
