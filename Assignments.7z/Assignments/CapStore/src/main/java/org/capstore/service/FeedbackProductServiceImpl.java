package org.capstore.service;


import java.util.List;

import org.capstore.dao.FeedbackProductDao;
import org.capstore.domain.FeedbackProduct;
import org.capstore.domain.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
public class FeedbackProductServiceImpl implements FeedbackProductService{

	
	@Autowired
	private FeedbackProductDao feedbackProductDao;
	
	@Transactional
	public void saveFeedbackProduct(FeedbackProduct feedbackProduct) {
		
		System.out.println(feedbackProduct);
		feedbackProductDao.saveFeedbackProduct(feedbackProduct);
			}

	@Transactional
	public List<Product> getAllProduct() {
		return feedbackProductDao.getAllProduct();
	}

}
