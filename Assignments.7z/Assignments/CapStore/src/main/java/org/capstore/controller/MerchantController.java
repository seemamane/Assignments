package org.capstore.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.capstore.domain.Merchant;
import org.capstore.domain.Product;
import org.capstore.service.MerchantService;
import org.capstore.service.MerchantServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MerchantController {

	

	@Autowired
	MerchantService merchantService=new MerchantServiceImpl();
	
	
	
	@RequestMapping("/merchant")
	public String showMerchantForm(Map<String, Object>maps){
		
		//SimpleDateFormat simpleDate=new SimpleDateFormat("dd-MMM-yyyy");
		maps.put("merchant1", new Merchant());
		
		maps.put("merchantType", getMerchantType().values());
		
	  return "merchant";		
	}
	
	@RequestMapping(value={"/saveMerchant"},method=RequestMethod.POST)
	   public ModelAndView savemerchant(@Valid @ModelAttribute("merchant1") Merchant merchant,BindingResult result,Map<String, Object>maps){
		
		if(result.hasErrors()){
			maps.put("merchantType", getMerchantType().values());
			return new ModelAndView("merchant");
		}
		else{
			System.out.println(merchant);
			/*productService.save(merchant);*/
			merchantService.saveMerchant(merchant);
		return new ModelAndView("redirect:merchant");
			/*return "redirect:merchant";*/
		}
		
	   }
		
	@RequestMapping("/showMerchant")
	public String showAllMerchant(Map<String, Object>maps){
		
		maps.put("merchants", merchantService.getAllMerchants());		
	return "showMerchant";	
	}

	
	@RequestMapping("/removeMerchant")
	public String ListAllMerchant(Map<String, Object>maps){
		
		maps.put("merchants", merchantService.getAllMerchants());		
	return "RemoveMerchant";	
	}
	
	@RequestMapping(value="/removeMerchantID/{merchant_id}")
	public String deleteProductByID(@PathVariable("merchant_id") Integer merchant_id,Map<String,Object>maps){
		
		
		List<Merchant> list=merchantService.getAllMerchants();
		maps.put("merchants",list);
		merchantService.deleteMerchant(merchant_id);
		
		
		return "redirect:/RemoveMerchant";
		
	}
	

	public Map<Integer, String> getMerchantType(){
		
		Map<Integer, String> maps=new HashMap<>();
		
		maps.put(1,"Merchant");
		maps.put(2,"Third Party Merchant");
		return maps;
		
	}
	
	
	
}
