package org.capstore.service;

import java.util.List;

import org.capstore.domain.FeedbackProduct;

import org.capstore.domain.Product;

public interface FeedbackProductService {

	
	public void saveFeedbackProduct(FeedbackProduct feedbackProduct);
	public List<Product> getAllProduct();
}
