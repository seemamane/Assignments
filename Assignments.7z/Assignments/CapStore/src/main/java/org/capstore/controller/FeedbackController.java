package org.capstore.controller;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.capstore.domain.Feedback;
import org.capstore.domain.FeedbackProduct;
import org.capstore.domain.Product;
import org.capstore.service.FeedbackProductService;
import org.capstore.service.FeedbackService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sun.media.sound.FFT;

@Controller
public class FeedbackController {

	@Autowired
	private FeedbackService feedbackService;

	@Autowired
	private FeedbackProductService feedbackProductService;



	@RequestMapping("/feedbackForm")
	public String showFeedbackForm(Map<String, Object> maps)
	{

		maps.put("feed", new Feedback());
		maps.put("mer", feedbackService.getAllMerchant());
		String message="There!";
		return "FeedbackForm";
	}


	@RequestMapping(value="/showFeedbackDetails",method=RequestMethod.POST)
	public ModelAndView showFeedbackDetails(@Valid @ModelAttribute("feed") Feedback feedback,
			BindingResult result,Map<String, Object> maps)
	{
		
		if(result.hasErrors())
		{
			
			maps.put("mer", feedbackService.getAllMerchant());
			return new ModelAndView("FeedbackForm");
		}

		else{
		feedbackService.saveFeedback(feedback);
		return new ModelAndView("showFeedback","mer",feedbackService.getAllMerchant());
		
		}

	}
	
	@RequestMapping("/listAllFeedback")
	public ModelAndView showAllFeedback(){
		return new ModelAndView("AcceptFeedback","feedbacks",feedbackService.getAllFeedback());
		
	}



	
	


	@RequestMapping("/feedbackProductForm")
	public String showFeedbackProductForm(Map<String, Object> maps)
	{

		maps.put("feedProduct", new FeedbackProduct());
		maps.put("pro", feedbackProductService.getAllProduct());
		String message="There!";
		return "FeedbackProductForm";
	}

	@RequestMapping(value="/showFeedbackProductDetails",method=RequestMethod.POST)
	public ModelAndView showFeedbackDetails(@Valid @ModelAttribute("feedProduct") FeedbackProduct feedbackProduct,
			BindingResult result,Map<String, Object> maps)
	{
		
		
		if(result.hasErrors())
		{
			
			maps.put("pro", feedbackProductService.getAllProduct());
			return new ModelAndView("FeedbackProductForm");
		}

		feedbackProductService.saveFeedbackProduct(feedbackProduct);
		return new ModelAndView("showFeedback","pro",feedbackProductService.getAllProduct());
		//  return "showFeedback";
	}








}



