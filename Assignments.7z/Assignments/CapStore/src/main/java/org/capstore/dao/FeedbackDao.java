package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Feedback;
import org.capstore.domain.Merchant;


public interface FeedbackDao {
	
	public void saveFeedback(Feedback feedback);
	
	public List<Merchant> getAllMerchant();

	public List<Feedback> getAllFeedback();

	/*public void acceptFeedback(Integer feedback_id);*/

}
