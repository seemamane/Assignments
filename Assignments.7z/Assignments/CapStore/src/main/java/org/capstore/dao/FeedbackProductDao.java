package org.capstore.dao;

import java.util.List;

import org.capstore.domain.FeedbackProduct;
import org.capstore.domain.Product;

public interface FeedbackProductDao {
	
	public void saveFeedbackProduct(FeedbackProduct feedbackProduct);
	public List<Product> getAllProduct();

}
