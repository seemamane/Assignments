package org.capstore.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class FeedbackProduct {
	
	@Id
	@GeneratedValue
	private int	feedback_product_id;

	
	@NotEmpty(message="*Please Enter Feedbacke")
	@Column(nullable=false)
	private String feedback_product;
	
	
	@NotEmpty(message="*Please Enter Customer Name")
	@Column(nullable=false)
	private String customer_name;

	@Transient
	@Column(nullable=true)
	private String product_name;
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="product_id_FK")
	private Product product;
	
	
	//no arg constructor
	
	public FeedbackProduct(){}

	//fully loaded constructor
	public FeedbackProduct(int feedback_product_id, String feedback_product, String customer_name, String product_name,
			Product product) {
		super();
		this.feedback_product_id = feedback_product_id;
		this.feedback_product = feedback_product;
		this.customer_name = customer_name;
		this.product_name = product_name;
		this.product = product;
	}

	//setters and getters
	public int getFeedback_product_id() {
		return feedback_product_id;
	}

	public void setFeedback_product_id(int feedback_product_id) {
		this.feedback_product_id = feedback_product_id;
	}

	public String getFeedback_product() {
		return feedback_product;
	}

	public void setFeedback_product(String feedback_product) {
		this.feedback_product = feedback_product;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	//to string method
	@Override
	public String toString() {
		return "FeedbackProduct [feedback_product_id=" + feedback_product_id + ", feedback_product=" + feedback_product
				+ ", customer_name=" + customer_name + ", product_name=" + product_name + ", product=" + product + "]";
	}

	
	
	
}

