package org.capstore.service;

import java.util.List;

import org.capstore.domain.Merchant;

public interface MerchantService {
	
	public void saveMerchant(Merchant merchant);
	public List<Merchant> getAllMerchants();
	
	public void deleteMerchant(Integer merchant_id);

}
