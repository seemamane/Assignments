package org.capstore.domain;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;

@Entity
public class Product {

	@Id
	@GeneratedValue
	private int product_id;
	
	@NotEmpty(message="*Please Enter Valid Product Name")
	@Size(min=5,max=30, message="Should be Between 5 to 30")
	private String product_name;
	
	
	@NotEmpty(message="* Please Enter Product Specification")
	private String specification;
	
	
	//@NotNull(message="* Please Enter Product Price")
	//@NumberFormat(style=Style.NUMBER,pattern="#######.#")
	private double price;
	
	//@NotEmpty(message="* Please Enter Prodcuct Posting Date")
	private Date date_of_posting;
	

	private int no_of_times_product_visited=0;
	
	
	@ManyToOne//(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumns({@JoinColumn(name="category_id_FK",referencedColumnName="category_id",insertable=true,updatable=true)})
	private Category category;


	@ManyToOne//(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumns({@JoinColumn(name="brand_id_FK",referencedColumnName="brand_id",insertable=true,updatable=true)})
	private Brand brand;
	
	
	@ManyToOne//(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumns({@JoinColumn(name="sub_category_id_FK",referencedColumnName="sub_category_id",insertable=true,updatable=true)})
	private Sub_category sub_category;
	
	@Transient
	@OneToOne//(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private Stock stock;
	
	
	@ManyToOne//(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumns({@JoinColumn(name="merchant_id_FK",referencedColumnName="merchant_id",insertable=true,updatable=true)})
	private Merchant merchant;
	
	
	
	public Product(){}
	
        public Product(int product_id, String product_name, String specification, double price, Date date_of_posting,
			int no_of_times_product_visited, Category category, Brand brand, Sub_category sub_category, Stock stock,
			Merchant merchant) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.specification = specification;
		this.price = price;
		this.date_of_posting = date_of_posting;
		this.no_of_times_product_visited = no_of_times_product_visited;
		this.category = category;
		this.brand = brand;
		this.sub_category = sub_category;
		this.stock = stock;
		this.merchant = merchant;
	}

	public Product(String product_name, String specification, double price, Date date_of_posting,
				int no_of_times_product_visited, Category category, Brand brand, Sub_category sub_category, Stock stock,
				Merchant merchant) {
			super();
			this.product_name = product_name;
			this.specification = specification;
			this.price = price;
			this.date_of_posting = date_of_posting;
			this.no_of_times_product_visited = no_of_times_product_visited;
			this.category = category;
			this.brand = brand;
			this.sub_category = sub_category;
			this.stock = stock;
			this.merchant = merchant;
		}

	public Sub_category getSub_category() {
		return sub_category;
	}


	public Stock getStock() {
		return stock;
	}


	public void setStock(Stock stock) {
		this.stock = stock;
	}


	public void setSub_category(Sub_category sub_category) {
		this.sub_category = sub_category;
	}


	public Merchant getMerchant() {
		return merchant;
	}


	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}
     
	
	public int getProduct_id() {
		return product_id;
	}


	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}


	public String getProduct_name() {
		return product_name;
	}


	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

    public Brand getBrand() {
		return brand;
	}


	public void setBrand(Brand brand) {
		this.brand = brand;
	}


	

	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public Date getDate_of_posting() {
		return date_of_posting;
	}


	public void setDate_of_posting(Date date_of_posting) {
		this.date_of_posting = date_of_posting;
	}


	public int getNo_of_times_product_visited() {
		return no_of_times_product_visited;
	}


	public void setNo_of_times_product_visited(int no_of_times_product_visited) {
		this.no_of_times_product_visited = no_of_times_product_visited;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}

	public String getSpecification() {
		return specification;
	}

	public void setSpecification(String specification) {
		this.specification = specification;
	}

	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", product_name=" + product_name + ", specification="
				+ specification + ", price=" + price + ", date_of_posting=" + date_of_posting
				+ ", no_of_times_product_visited=" + no_of_times_product_visited + ", category=" + category + ", brand="
				+ brand + ", sub_category=" + sub_category + ", stock=" + stock + ", merchant=" + merchant + "]";
	}

	
	
	
}
