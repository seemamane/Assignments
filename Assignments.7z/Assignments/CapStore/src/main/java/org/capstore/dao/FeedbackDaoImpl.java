package org.capstore.dao;

import java.util.ArrayList;
import java.util.List;

import org.capstore.domain.Feedback;
import org.capstore.domain.Merchant;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class FeedbackDaoImpl implements FeedbackDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	//@Transactional
	public void saveFeedback(Feedback feedback) {
	
			System.out.println(feedback);
			sessionFactory.getCurrentSession().saveOrUpdate(feedback);
		
	}

	@Override
	//@Transactional
	public List<Merchant> getAllMerchant() {
		
		List<Merchant>merchants= sessionFactory.getCurrentSession().createQuery("from Merchant").list();
		System.out.println(merchants);
		return merchants;
	}

	@Override
	public List<Feedback> getAllFeedback() {
		List<Feedback>feedbacks=new ArrayList<>();
		
		feedbacks=sessionFactory.getCurrentSession().createQuery("from Feedback").list();
		System.out.println(feedbacks);
		
		
		
		return feedbacks;
	}

	/*@Override
	public void acceptFeedback(Integer feedback_id) {
		
		sessionFactory.getCurrentSession().createQuery("insert into FeedbackApprove(feedback,status) values("+feedback_id+",1)").executeUpdate();
		
		
	}*/
	
	
	
	
	
	
	

}
