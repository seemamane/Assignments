package org.capstore.dao;

import java.util.ArrayList;
import java.util.List;

import org.capstore.domain.Brand;
import org.capstore.domain.Category;
import org.capstore.domain.Merchant;
import org.capstore.domain.Product;
import org.capstore.domain.Stock;
import org.capstore.domain.Sub_category;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;


@Repository("productDao")
public class ProductDaoImpl implements ProductDao{

	

	@Autowired
	public SessionFactory sessionFactory;
	
	@Override
	public List<Brand> getAllBrands() {
		List< Brand> brands=sessionFactory.getCurrentSession().createQuery("from Brand").list();
		
		//System.out.println(brands);
		
		return brands;
	}

	

	@Override
	public List<Sub_category> getAllSub_category() {
	List< Sub_category> sub_category=sessionFactory.getCurrentSession().createQuery("from Sub_category").list();
		
		//System.out.println(sub_category);
		
		return sub_category;
	}

	@Override
	public List<Stock> getAllStock() {
		
		List< Stock> stock=sessionFactory.getCurrentSession().createQuery("from Stock").list();
		
		//System.out.println(stock);
		
		return stock;
	}

	
	@Override
	public void saveProduct(Product product) {
		/* Session session = this.sessionFactory.getCurrentSession();
		session.beginTransaction();*/
		//System.out.println(product+"dao");
		sessionFactory.getCurrentSession().saveOrUpdate(product);
		System.out.println("DAO"+sessionFactory.getCurrentSession().createQuery("select product_id from Product order by product_id desc limit 1").list());
		//System.out.println("Commited");
		System.out.println(product.getProduct_id());
		Product product1=new Product();
		product1.setProduct_id(product.getProduct_id());
		Stock stock=product.getStock();
		stock.setProduct(product1);
		
		//int n=sessionFactory.getCurrentSession().createQuery("insert into Stock(no_of_items,product_id_FK) values("+product.getStock().getNo_of_items()+","+product.getProduct_id()+")").executeUpdate();
		//System.out.println("No of items"+n);
		sessionFactory.getCurrentSession().save(stock);
		
		System.out.println(product.getStock());
		
		
		/*Query query=session.createQuery("insert into purged_accounts(id, code, status) "+
			    "select id, code, status from acount where status=:status");
			query.setString("status", "purged");
			int rowsCopied=query.executeUpdate();*/
		/*session.getTransaction().commit();*/
	}
	
	
	@Override
	public List<Product> getAllProducts() {
		
		List<Product> products=new ArrayList<>();
		List<Product> products1=new ArrayList<>();
		products=sessionFactory.getCurrentSession().createQuery("from Product").list();
		for(Product prod:products){
			Category category=prod.getCategory();
			System.out.println(category.getCategory_id()+"id");
			Category categoryName=getCategoryById(category.getCategory_id());
			System.out.println(categoryName);
			prod.setCategory(categoryName);
			
			Sub_category subCategory=prod.getSub_category();
			//System.out.println("subcategory"+subCategory.getSub_category_id());
	        Sub_category subCategoryname=getSubCategoryByName(prod.getSub_category().getSub_category_id());
	        System.out.println("SUBCATEGORY"+subCategoryname);
	        prod.setSub_category(subCategoryname);
	        
	        
	        Brand brand=prod.getBrand();
	        Brand brandName=getBrandByID(brand.getBrand_id());
	        prod.setBrand(brandName);
	        
	        Merchant merchant=prod.getMerchant();
	        System.out.println("MERCHANT"+merchant);
	        
	        
	       /* Stock stock=prod.getStock();
	        System.out.println("STOCK"+stock.getProduct().getProduct_id());*/
	        
	        Stock stock=getStockBTID(prod.getProduct_id());
	        prod.setStock(stock);
	        
	        
	        System.out.println("PROD"+prod);
			products1.add(prod);
		}
		//System.out.println(products);
		System.out.println("list"+products1);
		 return products1;
	}



	private Stock getStockBTID(int product_id) {
		
		Stock stock=new Stock();
		List<Integer>no_of_items=sessionFactory.getCurrentSession().createQuery("select no_of_items from Stock where product_id_FK="+product_id).list();
		
		
		for(Integer items:no_of_items)
		{
			stock.setNo_of_items(items);
		}
		
		return stock;
	}



	private Brand getBrandByID(int brand_id) {
		Brand brand=new Brand();
		List<String>brand_name=sessionFactory.getCurrentSession().createQuery("select brand_name from Brand where brand_id="+brand_id).list();
		for(String name:brand_name)
		{
			brand.setBrand_name(name);
		}
		brand.setBrand_id(brand_id);


		return brand;
	}



	private Sub_category getSubCategoryByName(int sub_category_id) {
		Sub_category subCategory=new Sub_category();
		
		List<String>subCategory_name=sessionFactory.getCurrentSession().createQuery("select sub_category_name from Sub_category where sub_category_id="+sub_category_id).list();
		for(String name:subCategory_name)
		{
			subCategory.setSub_category_name(name);
		}
		subCategory.setSub_category_id(sub_category_id);
		return subCategory;
	}



	private Category getCategoryById(int category_id) {
		Category cateogry=new Category();
		//System.out.println(" getCategoryById"+sessionFactory.getCurrentSession().createQuery("select category_name from Category where category_id="+category_id).list());
		List<String> category_name=sessionFactory.getCurrentSession().createQuery("select category_name from Category where category_id="+category_id).list();
		for(String name:category_name){
		cateogry.setCategory_name(name);
		System.out.println("category name:"+cateogry.getCategory_name());
		}
		cateogry.setCategory_id(category_id);
		
		System.out.println(cateogry+"inmethod");
		return cateogry;
	}



	@Override
	public void deleteProduct(Integer product_id) {
		
		
		Product product=(Product) sessionFactory.getCurrentSession().get(Product.class, product_id);
		System.out.println("DAO PRODUCt"+product);
		System.out.println("DAO PRODUCT ID"+product_id);
		if(product!=null)
		{
			
			sessionFactory.getCurrentSession().createQuery("delete from Stock where product_id_FK="+product_id).executeUpdate();
			sessionFactory.getCurrentSession().delete(product);
		
	}
	}



	@Override
	public Product searchProduct(Integer product_id) {
		Product product=(Product) sessionFactory.getCurrentSession().get(Product.class, product_id);
		Stock stock=getStockBTID(product_id);
		product.setStock(stock);
		System.out.println(stock+"DAO");
		return product;
	}



}
