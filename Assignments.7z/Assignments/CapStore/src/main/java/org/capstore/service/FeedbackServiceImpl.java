package org.capstore.service;

import java.util.List;


import org.capstore.dao.FeedbackDao;

import org.capstore.domain.Feedback;
import org.capstore.domain.Merchant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
public class FeedbackServiceImpl implements FeedbackService{

	
	@Autowired
	private FeedbackDao feedbackDao;
	
    @Transactional
	public void saveFeedback(Feedback feedback) {
	
		
	

		
			System.out.println(feedback);
			feedbackDao.saveFeedback(feedback);
			
		}

	@Transactional
	public List<Merchant> getAllMerchant() {
		// TODO Auto-generated method stub
		return feedbackDao.getAllMerchant();
	}

	@Transactional
	public List<Feedback> getAllFeedback() {
		
		return feedbackDao.getAllFeedback();
	}

   /* @Transactional
 	public void acceptFeedback(Integer feedback_id) {
	
    	feedbackDao.acceptFeedback(feedback_id);
    	
    	
		
	}
*/

		
		
	}


