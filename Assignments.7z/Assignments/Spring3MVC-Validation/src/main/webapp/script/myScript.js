function myDateFormat(){
	alert('Hai');
	
}